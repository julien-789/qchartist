import sys
import pandas as pd
import mplfinance as mpf
import pandas_ta as ta
import talib

# --- Parse command line arguments ---
if len(sys.argv) < 5:
    print("Usage: python example4.py <csv_filename> <start_datetime> <end_datetime> <show_volume: yes|no>")
    print("Example: python example4.py 'YHOO1440.csv' '2014-01-01 00:00' '2015-06-01 16:00' yes")
    sys.exit(1)

csv_filename=sys.argv[1]
start_str = sys.argv[2]
end_str = sys.argv[3]
volume_flag = sys.argv[4].lower()

# Validate volume flag
if volume_flag not in ['yes', 'no']:
    print("Volume flag must be 'yes' or 'no'")
    sys.exit(1)

show_volume = volume_flag == 'yes'

# Parse start and end datetime
try:
    start_dt = pd.to_datetime(start_str)
    end_dt = pd.to_datetime(end_str)
except Exception as e:
    print(f"Error parsing datetime: {e}")
    sys.exit(1)

if start_dt > end_dt:
    print("Error: Start datetime must be before end datetime.")
    sys.exit(1)

# --- Load and filter data ---
idf = pd.read_csv(csv_filename, index_col=0, parse_dates=True)
idf.columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume']
idf.index = pd.to_datetime(idf.index)

df = idf.loc[(idf.index >= start_dt) & (idf.index <= end_dt)].copy()

if df.empty:
    print(f"No data available between {start_str} and {end_str}")
    sys.exit(1)

# Now proceed with your indicator calculation and plotting

# --- Now continue with the rest of your script ---
# (apply indicators, prompt user, plot etc.)

# Prompt user for date range to filter
#start_date = input("Enter start datetime (e.g. 2024-01-01 09:30): ").strip()
#end_date = input("Enter end datetime (e.g. 2024-06-01 16:00): ").strip()

# Filter the DataFrame by date range
#try:
#    df = df.loc[start_date:end_date]
#    if df.empty:
#        raise ValueError("No data in the selected range.")
#    print(f"Displaying data from {start_date} to {end_date}")
#except Exception as e:
#    print(f"Invalid date range or format. Error: {e}")
#    exit(1)

# List of overlay indicators (to be drawn on main chart)
overlay_indicators = {
    "sma", "ema", "wma", "hma", "kama", "zlma", "dema", "tema", "vwma",
    "bbands", "donchian", "psar", "SMA"
}

# Get all available indicators
#all_indicators = df.ta.indicators(as_list=True)
#print("Available indicators:")
#print(", ".join(all_indicators))

import inspect

# Load your data into df with Open, High, Low, Close, Volume columns
# df = ...

# Prepare dicts to hold results
pta_results = {}
talib_results = {}

close = df['Close']

import inspect

def get_all_pandas_ta_indicators():
#     Get all functions in pandas_ta module
    funcs = inspect.getmembers(ta, inspect.isfunction)
    
    # Filter out helpers or private ones that start with _
    indicators = [name for name, func in funcs if not name.startswith('_')]
    return indicators

all_indicators = get_all_pandas_ta_indicators()
print("All pandas-ta indicators found:")
print(all_indicators)

all_indicators = get_all_pandas_ta_indicators()

for ind_name in all_indicators:
    try:
        func = getattr(ta, ind_name)
        result = func(close)
        if isinstance(result, pd.Series):
            pta_results[ind_name] = result.rename(ind_name)
        elif isinstance(result, pd.DataFrame):
            pta_results.update({f"{ind_name}_{col}": result[col] for col in result.columns})
    except Exception as e:
        print(f"Skipping pandas-ta indicator {ind_name}: {e}")

# 2. TA-Lib all indicators (filter to uppercase function names only)
for ind_name, func in inspect.getmembers(talib, inspect.isbuiltin):
    if ind_name.isupper():
        try:
            result = func(df['Close'].values)
            # Convert numpy array to pd.Series
            talib_results[ind_name] = pd.Series(result, index=df.index, name=ind_name)
        except Exception as e:
            print(f"Skipping TA-Lib indicator {ind_name}: {e}")

# 3. Combine all into df
for name, series in pta_results.items():
    df[name] = series
for name, series in talib_results.items():
    df[name] = series

#for name, series in talib_results.items():
    #print (series)

# Now df has all indicators

# Get all available indicators
#all_indicators = df.ta.indicators(as_list=True)
#print("Available indicators:")
#print(", ".join(all_indicators))

#pta_indicators = get_all_pandas_ta_indicators()
#talib_indicators = list(talib_results.keys())

# Combine and sort (remove duplicates just in case)
#all_indicators_combined = sorted(set(pta_indicators) | set(talib_indicators))

#print("Available indicators (pandas-ta + TA-Lib):")
#print(", ".join(all_indicators_combined))

pta_indicators = get_all_pandas_ta_indicators()
talib_indicators = [name for name, func in inspect.getmembers(talib, inspect.isfunction) if name.isupper()]

all_indicators_combined = sorted(set(pta_indicators) | set(talib_indicators))

print("Available indicators (pandas-ta + TA-Lib):")
print(", ".join(all_indicators_combined))

# Prompt user to select indicators
#selected = input("Enter indicators to apply (comma-separated, case-sensitive): ").split(',')
#selected = [i.strip() for i in selected if i.strip() in all_indicators]

selected = input("Enter indicators to apply (comma-separated, case-sensitive): ").split(',')
selected = [i.strip() for i in selected if i.strip() in all_indicators_combined]


if not selected:
    raise ValueError("No valid indicators selected.")

original_cols = set(df.columns)
apds = []
panel_counter = 2 if show_volume else 1

for ind in selected:
    print(f"\n--- Help for {ind} ---")
    if ind in pta_indicators:
        help(getattr(ta, ind))
    elif ind in talib_indicators:
        help(getattr(talib, ind))
    else:
        print(f"No help available for {ind}")

    params = input(f"Enter parameters for `{ind}` as Python kwargs (e.g. length=14), or leave blank: ")
    kwargs = {}
    if params:
        try:
            kwargs = eval(f"dict({params})")
        except Exception as e:
            print(f"Invalid parameters: {e}. Skipping {ind}.")
            continue

    try:
        if ind in pta_indicators:
            df.ta.__getattribute__(ind)(**kwargs, append=True)
        elif ind in talib_indicators:
            func = getattr(talib, ind)
            try:
                result = func(df['Close'].values, **kwargs)
            except TypeError:
                try:
                    result = func(df['High'].values, df['Low'].values, df['Close'].values, **kwargs)
                except Exception as e:
                    print(f"Failed to apply TA-Lib indicator {ind} with multi-input: {e}")
                    continue

            new_cols_data = {}
            if isinstance(result, (tuple, list)):
                for i, arr in enumerate(result):
                    col_name = f"{ind}_{i+1}"
                    new_cols_data[col_name] = pd.Series(arr, index=df.index).astype(float)
            else:
                new_cols_data[ind] = pd.Series(result, index=df.index).astype(float)

            if new_cols_data:
                df = pd.concat([df, pd.DataFrame(new_cols_data)], axis=1)

        else:
            print(f"Indicator {ind} not found in pandas-ta or TA-Lib.")
            continue
    except Exception as e:
        print(f"Failed to apply {ind}: {e}")
        continue

    # Detect new columns added AFTER concatenation, BEFORE updating original_cols
    new_cols = list(set(df.columns) - original_cols)
    # Filter only numeric new columns
    new_cols = [col for col in new_cols if pd.api.types.is_numeric_dtype(df[col])]

    if not new_cols:
        print(f"No numeric columns found for {ind}.")
        continue

    # Now update the original_cols with these new columns
    original_cols.update(new_cols)

    if ind in overlay_indicators:
        for col in new_cols:
            apds.append(mpf.make_addplot(df[col], panel=0))
    else:
        for idx, col in enumerate(new_cols):
            if idx == 0:
                apds.append(mpf.make_addplot(df[col], panel=panel_counter, ylabel=ind.upper()))
            else:
                apds.append(mpf.make_addplot(df[col], panel=panel_counter))
        panel_counter += 1

# Plot with proper panels and labels
#mpf.plot(df, type='candle', volume=True, addplot=apds, title="Custom Pandas-TA Chart")

from PIL import Image

# Create the figure object manually to enable saving
fig, axes = mpf.plot(
    df,
    type='candle',
    volume=show_volume,
    addplot=apds,
    title="Custom Pandas- TA -Lib Chart",
    returnfig=True  # Needed to access the figure for saving
)

# Save the figure as BMP
fig.savefig("custom_chart.png", format="png")

# Convert to BMP
img = Image.open("custom_chart.png")
img.save("custom_chart.bmp", format="BMP")
print("Chart saved as custom_chart.bmp")
