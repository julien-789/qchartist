from pycoingecko import CoinGeckoAPI

def save_all_coin_ids(filename="coingecko_coin_ids.txt"):
    cg = CoinGeckoAPI()
    coins = cg.get_coins_list()  # returns list of dicts with 'id', 'symbol', 'name'

    # Extract just the coin ids
    coin_ids = [coin['id'] for coin in coins]

    # Save to text file
    with open(filename, 'w') as f:
        for coin_id in coin_ids:
            f.write(coin_id + '\n')

    print(f"Saved {len(coin_ids)} coin IDs to '{filename}'")

if __name__ == "__main__":
    save_all_coin_ids()
