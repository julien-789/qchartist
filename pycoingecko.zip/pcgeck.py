import argparse
import csv
from pycoingecko import CoinGeckoAPI
from datetime import datetime, timedelta

def parse_interval(interval_str):
    if interval_str.endswith("min"):
        return int(interval_str.replace("min", ""))
    elif interval_str.endswith("h"):
        return int(interval_str.replace("h", "")) * 60
    else:
        raise ValueError("Unsupported interval format: use '5min', '1h', etc.")

def floor_timestamp(dt, interval_minutes):
    return dt - timedelta(
        minutes=dt.minute % interval_minutes,
        seconds=dt.second,
        microseconds=dt.microsecond
    )

def main():
    parser = argparse.ArgumentParser(description="Download OHLCV data from CoinGecko")
    parser.add_argument("coin_id", type=str, help="CoinGecko coin id (e.g., bitcoin, ripple)")
    parser.add_argument("--interval", type=str, default="5min", help="Interval like '5min', '15min', '1h'")
    parser.add_argument("--days", type=str, default="33", help="Number of days or 'max'")
    args = parser.parse_args()

    coin_id = args.coin_id
    interval_str = args.interval
    days = args.days
    interval_minutes = parse_interval(interval_str)

    cg = CoinGeckoAPI()
    data = cg.get_coin_market_chart_by_id(id=coin_id, vs_currency="usd", days=days)

    prices = data.get("prices", [])
    volumes = data.get("total_volumes", [])

    if not prices or not volumes:
        print("No data received from CoinGecko.")
        return

    # Build a dict of timestamp -> (price, volume)
    price_dict = {ts: price for ts, price in prices}
    volume_dict = {ts: volume for ts, volume in volumes}

    # Combine and convert to datetime
    records = []
    for ts in sorted(set(price_dict) & set(volume_dict)):
        dt = datetime.utcfromtimestamp(ts / 1000)
        price = price_dict[ts]
        volume = volume_dict[ts]
        records.append((dt, price, volume))

    if not records:
        print("No matching price and volume records.")
        return

    # Determine start and end times
    records.sort()
    start_time = floor_timestamp(records[0][0], interval_minutes)
    end_time = floor_timestamp(records[-1][0], interval_minutes)

    # Group by floored timestamps
    from collections import defaultdict
    grouped = defaultdict(list)
    for dt, price, volume in records:
        bucket = floor_timestamp(dt, interval_minutes)
        grouped[bucket].append((dt, price, volume))

    # Create time range
    current_time = start_time
    last_close = None
    result = []

    while current_time <= end_time:
        entries = grouped.get(current_time, [])

        if entries:
            entries.sort()
            prices = [e[1] for e in entries]
            volumes = [e[2] for e in entries]
            o = prices[0]
            h = max(prices)
            l = min(prices)
            c = prices[-1]
            v = sum(volumes)
            last_close = c
        elif last_close is not None:
            o = h = l = c = last_close
            v = 0.0
        else:
            current_time += timedelta(minutes=interval_minutes)
            continue  # Skip initial empty rows before any data

        result.append([
            current_time.strftime("%Y-%m-%d"),
            current_time.strftime("%H:%M"),
            f"{o:.6f}", f"{h:.6f}", f"{l:.6f}", f"{c:.6f}", f"{v:.6f}"
        ])
        current_time += timedelta(minutes=interval_minutes)

    if not result:
        print("No valid data to write.")
        return

    filename = f"{coin_id}_ohlcv_{interval_str}.csv"
    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(result)

    print(f"Saved {coin_id} OHLCV data resampled at {interval_str} interval to '{filename}'")

if __name__ == "__main__":
    main()

