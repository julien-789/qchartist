import sys
import csv
from datetime import datetime
from tkinter import Tk, Canvas
from screeninfo import get_monitors
import argparse

# --- Indicator Calculations ---
def calculate_rsi(data, period=14):
    closes = [row[4] for row in data]
    rsi = [None] * len(closes)
    for i in range(period, len(closes)):
        gains = [max(0, closes[j] - closes[j-1]) for j in range(i - period + 1, i + 1)]
        losses = [max(0, closes[j-1] - closes[j]) for j in range(i - period + 1, i + 1)]
        avg_gain = sum(gains) / period
        avg_loss = sum(losses) / period
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
    return rsi

def calculate_macd(data, fast=12, slow=26, signal=9):
    closes = [row[4] for row in data]

    def ema(values, period):
        ema_values = [None] * len(values)
        k = 2 / (period + 1)
        for i in range(len(values)):
            if i < period:
                continue
            elif i == period:
                sma = sum(values[i - period + 1:i + 1]) / period
                ema_values[i] = sma
            else:
                if ema_values[i - 1] is not None:
                    ema_values[i] = values[i] * k + ema_values[i - 1] * (1 - k)
        return ema_values

    ema_fast = ema(closes, fast)
    ema_slow = ema(closes, slow)
    macd = [None if (f is None or s is None) else f - s for f, s in zip(ema_fast, ema_slow)]
    signal_line = ema([v if v is not None else 0 for v in macd], signal)
    histogram = [None if (m is None or s is None) else m - s for m, s in zip(macd, signal_line)]

    return macd, signal_line, histogram

def calculate_mfi(data, period=14):
    mfi = [None] * len(data)
    for i in range(period, len(data)):
        pos_flow = 0
        neg_flow = 0
        for j in range(i - period + 1, i + 1):
            tp = (data[j][2] + data[j][3] + data[j][4]) / 3
            prev_tp = (data[j-1][2] + data[j-1][3] + data[j-1][4]) / 3
            flow = tp * data[j][5]
            if tp > prev_tp:
                pos_flow += flow
            elif tp < prev_tp:
                neg_flow += flow
        if neg_flow == 0:
            mfi[i] = 100
        else:
            ratio = pos_flow / neg_flow
            mfi[i] = 100 - (100 / (1 + ratio))
    return mfi

# --- Read Data ---
def load_csv(path, start_dt, end_dt):
    data = []
    with open(path) as f:
        reader = csv.reader(f)
        for row in reader:
            try:
                dt = datetime.strptime(f"{row[0]} {row[1]}", "%Y-%m-%d %H:%M")
            except Exception:
                continue
            if not (start_dt <= dt <= end_dt):
                continue
            o, h, l, c, v = map(float, row[2:])
            data.append([dt, o, h, l, c, v])
    return data

def save_canvas_as_png(canvas, filename_prefix="chart"):
    ps_filename = filename_prefix + ".ps"
    # Ensure the canvas is updated/rendered before saving
    canvas.update()
    canvas.postscript(file=ps_filename, colormode='color')
    print(f"Saved chart to: {ps_filename}")
    print(f"To convert to PNG, use:")
    print(f"  gs -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pngalpha -r144 -sOutputFile={filename_prefix}.png {ps_filename}")

# --- Draw Chart ---
def draw_chart(data, rsi, macd, mfi, selected_indicators):
    monitor = get_monitors()[0]
    screen_width = monitor.width
    screen_height = monitor.height

    # Layout variables
    main_height = 200
    panel_height = 100
    spacing = 20
    top_margin = 50

    # Number of selected panels to draw
    panel_count = 0
    if "rsi" in selected_indicators and rsi:
        panel_count += 1
    if "macd" in selected_indicators and macd[0] and macd[1]:
        panel_count += 1
    if "mfi" in selected_indicators and mfi:
        panel_count += 1

    height = top_margin + main_height + panel_count * (panel_height + spacing) + 50
    width = screen_width - 100
    if height > screen_height - 100:
        height = screen_height - 100  # limit height to screen height with some margin

    root = Tk()
    root.title("Stock Chart")
    canvas = Canvas(root, width=width, height=height, bg="white")
    canvas.pack()

    def draw_axis(y_start, panel_height, min_val, max_val):
        canvas.create_line(50, y_start, 50, y_start + panel_height, fill="black")
        for i in range(6):
            y = y_start + i * panel_height / 5
            val = max_val - i * (max_val - min_val) / 5
            canvas.create_text(30, y, text=f"{val:.1f}", anchor="e", font=("Arial", 8))

    def draw_x_axis(data_len, x_offset, y_pos):
        canvas.create_line(x_offset, y_pos, width - 20, y_pos, fill="black")
        step = max(1, data_len // 10)
        for i in range(0, data_len, step):
            dt_str = data[i][0].strftime("%m-%d")
            x = x_offset + i * (width - x_offset - 20) / data_len
            canvas.create_text(x, y_pos + 10, text=dt_str, anchor="n", font=("Arial", 8))

    # Main Price Chart
    max_price = max(row[2] for row in data)
    min_price = min(row[3] for row in data)
    draw_axis(top_margin, main_height, min_price, max_price)

    x_step = (width - 70) / len(data)
    for i, row in enumerate(data):
        dt, o, h, l, c, v = row
        x = 50 + i * x_step
        y_open = top_margin + (max_price - o) / (max_price - min_price) * main_height
        y_close = top_margin + (max_price - c) / (max_price - min_price) * main_height
        y_high = top_margin + (max_price - h) / (max_price - min_price) * main_height
        y_low = top_margin + (max_price - l) / (max_price - min_price) * main_height
        color = "green" if c >= o else "red"
        canvas.create_line(x, y_high, x, y_low, fill=color)
        canvas.create_line(x, y_open, x, y_close, fill=color, width=3)

    draw_x_axis(len(data), 50, top_margin + main_height)

    def draw_panel(indicator, top, label, color="blue"):
        valid = [v for v in indicator if v is not None]
        if not valid:
            return
        min_val = min(valid)
        max_val = max(valid)
        if min_val == max_val:
            max_val += 1  # prevent division by zero
        draw_axis(top, panel_height, min_val, max_val)
        for i in range(1, len(data)):
            if indicator[i] is None or indicator[i - 1] is None:
                continue
            x1 = 50 + (i - 1) * x_step
            x2 = 50 + i * x_step
            y1 = top + (max_val - indicator[i - 1]) / (max_val - min_val) * panel_height
            y2 = top + (max_val - indicator[i]) / (max_val - min_val) * panel_height
            canvas.create_line(x1, y1, x2, y2, fill=color)
        canvas.create_text(60, top + 10, text=label, anchor="w", font=("Arial", 10, "bold"))
        draw_x_axis(len(data), 50, top + panel_height)

    panel_index = 0
    if "rsi" in selected_indicators and rsi:
        draw_panel(rsi, top_margin + main_height + panel_index * (panel_height + spacing), "RSI (14)", color="purple")
        panel_index += 1
    if "macd" in selected_indicators and macd[0] and macd[1]:
        # Draw MACD and Signal line in the same panel
        top = top_margin + main_height + panel_index * (panel_height + spacing)
        draw_panel(macd[0], top, "MACD", color="orange")
        draw_panel(macd[1], top, "Signal", color="green")
        panel_index += 1
    if "mfi" in selected_indicators and mfi:
        draw_panel(mfi, top_margin + main_height + panel_index * (panel_height + spacing), "MFI", color="brown")

    # Update canvas and save
    root.update()
    save_canvas_as_png(canvas, "full_chart")

    # Keep window open until user closes it
    root.mainloop()

# --- Main ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Draw stock chart with optional indicators.")
    parser.add_argument("csv_file", help="Path to CSV file")
    parser.add_argument("start_date", help="Start date in YYYY-MM-DD HH:MM")
    parser.add_argument("end_date", help="End date in YYYY-MM-DD HH:MM")
    parser.add_argument("--indicators", default="rsi,macd,mfi",
                        help="Comma-separated list of indicators to include (rsi, macd, mfi)")

    args = parser.parse_args()
    start_dt = datetime.strptime(args.start_date, "%Y-%m-%d %H:%M")
    end_dt = datetime.strptime(args.end_date, "%Y-%m-%d %H:%M")
    selected_indicators = set(ind.strip().lower() for ind in args.indicators.split(","))

    data = load_csv(args.csv_file, start_dt, end_dt)
    if not data:
        print("No data found in the specified range.")
        sys.exit(1)

    rsi = calculate_rsi(data) if "rsi" in selected_indicators else None
    macd = calculate_macd(data) if "macd" in selected_indicators else (None, None, None)
    mfi = calculate_mfi(data) if "mfi" in selected_indicators else None

    draw_chart(data, rsi, macd, mfi, selected_indicators)
