import sys
import pandas as pd
import mplfinance as mpf
import pandas_ta as ta
import talib
from finta import TA  # finta import
import inspect
from PIL import Image

# --- Parse command line arguments ---
if len(sys.argv) < 5:
    print("Usage: python example4.py <csv_filename> <start_datetime> <end_datetime> <show_volume: yes|no>")
    print("Example: python example4.py 'YHOO1440.csv' '2014-01-01 00:00' '2015-06-01 16:00' yes")
    sys.exit(1)

csv_filename=sys.argv[1]
start_str = sys.argv[2]
end_str = sys.argv[3]
volume_flag = sys.argv[4].lower()

if volume_flag not in ['yes', 'no']:
    print("Volume flag must be 'yes' or 'no'")
    sys.exit(1)

show_volume = volume_flag == 'yes'

try:
    start_dt = pd.to_datetime(start_str)
    end_dt = pd.to_datetime(end_str)
except Exception as e:
    print(f"Error parsing datetime: {e}")
    sys.exit(1)

if start_dt > end_dt:
    print("Error: Start datetime must be before end datetime.")
    sys.exit(1)

# --- Load and filter data ---
idf = pd.read_csv(csv_filename, index_col=0, parse_dates=True)
idf.columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume']
idf.index = pd.to_datetime(idf.index)

df = idf.loc[(idf.index >= start_dt) & (idf.index <= end_dt)].copy()

if df.empty:
    print(f"No data available between {start_str} and {end_str}")
    sys.exit(1)

close = df['Close']

# --- Helper functions ---
def get_all_pandas_ta_indicators():
    funcs = inspect.getmembers(ta, inspect.isfunction)
    return [name for name, func in funcs if not name.startswith('_')]

def get_all_talib_indicators():
    return [name for name, func in inspect.getmembers(talib, inspect.isfunction) if name.isupper()]

def get_all_finta_indicators():
    # All callable methods in finta.TA class that do not start with _
    return [name for name, func in inspect.getmembers(TA, predicate=inspect.isfunction) if not name.startswith('_')]

pta_indicators = get_all_pandas_ta_indicators()
talib_indicators = get_all_talib_indicators()
finta_indicators = get_all_finta_indicators()

all_indicators_combined = sorted(set(pta_indicators) | set(talib_indicators) | set(finta_indicators))

print("Available indicators (pandas-ta + TA-Lib + finta):")
print(", ".join(all_indicators_combined))

# --- Prompt user to select indicators ---
selected = input("Enter indicators to apply (comma-separated, case-sensitive): ").split(',')
selected = [i.strip() for i in selected if i.strip() in all_indicators_combined]

if not selected:
    raise ValueError("No valid indicators selected.")

original_cols = set(df.columns)
apds = []
panel_counter = 2 if show_volume else 1

overlay_indicators = {
    "sma", "ema", "wma", "hma", "kama", "zlma", "dema", "tema", "vwma",
    "bbands", "donchian", "psar", "SMA"
}

for ind in selected:
    print(f"\n--- Help for {ind} ---")
    if ind in pta_indicators:
        help(getattr(ta, ind))
    elif ind in talib_indicators:
        help(getattr(talib, ind))
    elif ind in finta_indicators:
        help(getattr(TA, ind))
    else:
        print(f"No help available for {ind}")

    params = input(f"Enter parameters for `{ind}` as Python kwargs (e.g. length=14), or leave blank: ")
    kwargs = {}
    if params:
        try:
            kwargs = eval(f"dict({params})")
        except Exception as e:
            print(f"Invalid parameters: {e}. Skipping {ind}.")
            continue

    try:
        if ind in pta_indicators:
            # pandas-ta append=True appends result columns automatically
            df.ta.__getattribute__(ind)(**kwargs, append=True)

        elif ind in talib_indicators:
            func = getattr(talib, ind)
            try:
                # Try single input (Close)
                result = func(df['Close'].values, **kwargs)
            except TypeError:
                # Try OHLC inputs if single fails
                try:
                    result = func(df['High'].values, df['Low'].values, df['Close'].values, **kwargs)
                except Exception as e:
                    print(f"Failed TA-Lib indicator {ind} with multi-input: {e}")
                    continue

            new_cols_data = {}
            if isinstance(result, (tuple, list)):
                for i, arr in enumerate(result):
                    col_name = f"{ind}_{i+1}"
                    new_cols_data[col_name] = pd.Series(arr, index=df.index).astype(float)
            else:
                new_cols_data[ind] = pd.Series(result, index=df.index).astype(float)

            if new_cols_data:
                df = pd.concat([df, pd.DataFrame(new_cols_data)], axis=1)

        elif ind in finta_indicators:
            # finta expects columns: ['Open','High','Low','Close','Volume']
            # finta returns DataFrame or Series
            result = getattr(TA, ind)(df, **kwargs)
            if isinstance(result, pd.Series):
                df[ind] = result
            elif isinstance(result, pd.DataFrame):
                # Multiple columns, add all with prefix
                for col in result.columns:
                    df[f"{ind}_{col}"] = result[col]
            else:
                print(f"Unexpected result type from finta indicator {ind}: {type(result)}")
                continue

        else:
            print(f"Indicator {ind} not found in pandas-ta, TA-Lib or finta.")
            continue

    except Exception as e:
        print(f"Failed to apply {ind}: {e}")
        continue

    new_cols = list(set(df.columns) - original_cols)
    new_cols = [col for col in new_cols if pd.api.types.is_numeric_dtype(df[col])]

    if not new_cols:
        print(f"No numeric columns found for {ind}.")
        continue

    original_cols.update(new_cols)

    if ind.lower() in overlay_indicators or ind.upper() in overlay_indicators:
        for col in new_cols:
            apds.append(mpf.make_addplot(df[col], panel=0))
    else:
        for idx, col in enumerate(new_cols):
            if idx == 0:
                apds.append(mpf.make_addplot(df[col], panel=panel_counter, ylabel=ind.upper()))
            else:
                apds.append(mpf.make_addplot(df[col], panel=panel_counter))
        panel_counter += 1

# --- Plotting ---
fig, axes = mpf.plot(
    df,
    type='candle',
    volume=show_volume,
    addplot=apds,
    title="Custom Pandas-TA + TA-Lib + finta Chart",
    returnfig=True
)

fig.savefig("custom_chart.png", format="png")

img = Image.open("custom_chart.png")
img.save("custom_chart.bmp", format="BMP")
print("Chart saved as custom_chart.bmp")

